echo "docker exec -it df63416d1d0f bash"
echo "mysqldump -u garellano -pgarellano petstore > /scripts/db.sql"
echo "cp /Users/garellano/development/code/curso-is/proyecto-backend/src/main/resources/db/db.sql ."

echo "Usung dump.sh with following content:"
echo "docker exec -it container-proyecto-backend-db bash ./dump.sh"
