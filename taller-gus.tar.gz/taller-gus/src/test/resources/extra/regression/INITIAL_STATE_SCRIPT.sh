echo "(***) Estableciendo estado inicial con base en el script SQL: $1"
